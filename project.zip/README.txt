COMP 425 Project 
Iymen Abdella March 29 2022

Part 1:
- can be executed as normal. 
- Training results were inconclusive because optimizer could not be adjusted. 
- some of the parameters have to be modified in order to work with part 2. Unfortunately I could not make them polymorphic with both.
- Display functions work to show inconclusive data. 

Part 2:
- Did not implement the custom conv 2d.
- Does not execute as expected. 
- 2.3 completed and displays results. 
- kernel was displayed in multiple dimensions, since there are 3 channels. 

While some of the functionality does not work, I hope some of the coding and quality will demonstrate the hard work i put into this project. 
If i had more time i would spend more time fine tuning Part 1 and ensuring polymorphism with Part 2